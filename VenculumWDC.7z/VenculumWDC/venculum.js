(function() {
    // Create the connector object
    var myConnector = tableau.makeConnector();

    // Define the schema
    myConnector.getSchema = function(schemaCallback) {
        var cols = [{
            id: "OrderNo",
            dtaType: tableau.dataTypeEnum.string
        }, {
            id: "OrderDate",
            alias: "magnitude",
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "Status",
            alias: "title",
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "Total",
            dataType: tableau.dataTypeEnum.string
        }];

        var tableSchema = {
            id: "VenculumDataFeed",
            alias: "Venculum Data Feed for OrderPull",
            columns: cols
        };

        schemaCallback([tableSchema]);
    };

    // Download the data
    myConnector.getData = function(table, doneCallback) {
        $.getJSON("https://fabindiadev.herokuapp.com/orders.php", function(resp) {   
			var feat = resp.orderList,
                tableData = [];
			
            for (var i = 0, len = feat.length; i < len; i++) {
				const peopleArray = Object.values(feat[i]);
				for (var j = 0, len1 = peopleArray.length; j < len1; j++) 
				{
					tableData.push({
                    "OrderNo": peopleArray[j].orderNo,
                    "OrderDate": peopleArray[j].orderDate,
                    "Status": peopleArray[j].subTotal,
                    "Total": peopleArray[j].subTotal

                });
				}
				
            }

            table.appendRows(tableData);
            doneCallback();
        });
    };

    tableau.registerConnector(myConnector);

    // Create event listeners for when the user submits the form
    $(document).ready(function() {
        $("#submitButton").click(function() {
            tableau.connectionName = "Venculum Data Feed"; // This will be the data source name in Tableau
            tableau.submit(); // This sends the connector object to Tableau
        });
    });
})();
