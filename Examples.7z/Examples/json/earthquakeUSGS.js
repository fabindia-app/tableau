(function() {
    // Create the connector object
    var myConnector = tableau.makeConnector();

    // Define the schema
    myConnector.getSchema = function(schemaCallback) {
        var cols = [{
            id: "responseCode",
			alias: "Response Code"
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "totalOrders",
            alias: "Total Orders",
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "totalPages",
            alias: "Total Pages
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "responseMessage",
			alias: "Response Message"
            dataType: tableau.dataTypeEnum.string
        }];

        var tableSchema = {
            id: "earthquakeFeed",
            alias: "Earthquakes with magnitude greater than 4.5 in the last seven days",
            columns: cols
        };

        schemaCallback([tableSchema]);
    };

    // Download the data
    myConnector.getData = function(table, doneCallback) {
        $.getJSON("https://fabindiadev.herokuapp.com/orders.php", function(resp) {   
			var feat = resp.orderList,
                tableData = [];
			len = feat.length
            for (var i = 0; i < len; i++) 
			{
				for(j=0;j<len;j++)
				{
					tableData.push(
					{
						"responseCode": resp.responseCode,
						"totalOrders": resp.totalOrders,
						"totalPages": resp.totalPages,
						"responseMessage": resp.responseMessage
					});
				}
			}

            table.appendRows(tableData);
            doneCallback();
        });
    };

    tableau.registerConnector(myConnector);

    // Create event listeners for when the user submits the form
    $(document).ready(function() {
        $("#submitButton").click(function() {
            tableau.connectionName = "USGS Earthquake Feed"; // This will be the data source name in Tableau
            tableau.submit(); // This sends the connector object to Tableau
        });
    });
})();
