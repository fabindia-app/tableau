<?php

header('Access-Control-Allow-Origin: *');  
//
// A very simple PHP example that sends a HTTP POST to a remote site
//

$ch = curl_init();


$requestData = 'ApiOwner=02nanostuffs&ApiKey=1afe111acc2c46de83f0c11d08271c02e82244220f1a49d99eeba70&RequestBody={"phone":[""],
"email_id": ["aniljha@nanostuffs.com"],"pageNumber": ""}';



curl_setopt($ch, CURLOPT_URL,"http://static.vineretail.com/RestWS/api/eretail/v1/order/customerOrder");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$requestData);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$server_output = curl_exec($ch);

curl_close ($ch);
$myResponse = array();
$finalResponse = array();
$data = json_decode($server_output);
for($i=0;$i<count($data->orderList) ;$i++ )
{
$myResponse[] = json_decode(json_encode($data->orderList[$i]), true);

}

for($j=0;$j<count($myResponse);$j++)
{
foreach($myResponse[$j] as $row)
{
$finalResponse[] = $row;
}
}

echo json_encode($finalResponse);
?>