(function() {
    // Create the connector object
    var myConnector = tableau.makeConnector();

    // Define the schema
    myConnector.getSchema = function(schemaCallback) {
        var cols = [{
            id: "OrderNo",
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "OrderDate",
            alias: "orderDate",
            dataType: tableau.dataTypeEnum.string
        }, {
            id: "Status",
            alias: "status",
            dataType: tableau.dataTypeEnum.string
        },{
			id: "Currency",
			dataType: tableau.dataTypeEnum.string
		},{
            id: "OrderAmount",
            dataType: tableau.dataTypeEnum.string
        },{
			id: "ItemQty",
			dataType: tableau.dataTypeEnum.string
		}];

        var tableSchema = {
            id: "VenculumDataFeed",
            alias: "Venculum Data Feed for OrderPull",
            columns: cols
        };

        schemaCallback([tableSchema]);
    };

    // Download the data
    myConnector.getData = function(table, doneCallback) {
        $.getJSON("https://fabindiadev.herokuapp.com/orders.php", function(resp) {   
			var feat = resp,
				tableData = [];
			//console.log('feat'+feat);
			
			
            for (var i = 0, len = feat.length; i < len; i++) 
			{
				alert(resp[i].items[1]);
					tableData.push(
					{
                     "OrderNo": resp[i].orderNo,
                    "OrderDate": resp[i].orderDate,
                    "Status": resp[i].status,
                    "OrderAmount": resp[i].orderAmount,
					"Currency": resp[i].currency,
					"ItemQty":resp[i].items.length
				
				});
				
				
            }

            table.appendRows(tableData);
            doneCallback();
        });
    };

    tableau.registerConnector(myConnector);

    // Create event listeners for when the user submits the form
    $(document).ready(function() {
        $("#submitButton").click(function() {
            tableau.connectionName = "Venculum Data Feed"; // This will be the data source name in Tableau
            tableau.submit(); // This sends the connector object to Tableau
        });
    });
})();
