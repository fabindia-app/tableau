(function() {
    // Create the connector object
    var myConnector = tableau.makeConnector();

    // Define the schema
    myConnector.getSchema = function(schemaCallback) {
        var cols = [{
            id: "OrderNo",alias: "orderCurrency",
            dataType: tableau.dataTypeEnum.string
        },{
			id: "PaymentMethod",alias: "orderCurrency",
			dataType: tableau.dataTypeEnum.string
		},{
            id: "Status",
            alias: "status",
            dataType: tableau.dataTypeEnum.string
        },{
            id: "OrderDate",
            alias: "orderDate",
            dataType: tableau.dataTypeEnum.string
        },{
            id: "OrderAmount",
			alias: "orderAmount",
            dataType: tableau.dataTypeEnum.string
        }, {
			id: "OrderCurrency",
			alias: "orderCurrency",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "ShipCity",
			alias: "shipCity",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "ShipState",
			alias: "shipState",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "ShipCountry",
			alias: "shipCountry",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "ShipPincode",
			alias: "shipPincode",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "ShippingCharges",
			alias: "shippingCharges",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "StoreCredit",
			alias: "storeCredit",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "Giftvoucher",
			alias: "giftvoucher",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "OtherDiscount",alias: "orderCurrency",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "DiscountCode",
			alias: "DiscountCode",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "PromoCode",
			alias: "promoCode",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "PromoName",
			alias: "promoName",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "DiscountAmount",
			alias: "discountAmount",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "TaxAmount",
			alias: "taxAmount",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "UpdatedDate",
			alias: "updatedDate",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "TotalOrderLine",
			alias: "totalOrderLine",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "OrderSource",
			alias: "orderSource",
			dataType: tableau.dataTypeEnum.string
		},{
			id: "ItemQty",
			alias: "itemQty",
			dataType: tableau.dataTypeEnum.string
		}];

        var tableSchema = {
            id: "VenculumDataFeed",
            alias: "Venculum Data Feed for OrderPull",
            columns: cols
        };

        schemaCallback([tableSchema]);
    };

    // Download the data
    myConnector.getData = function(table, doneCallback) {
        $.getJSON("https://fabindiadev.herokuapp.com/orderpull.php", function(resp) {   
			var feat = resp,
                tableData = [];
			
			
            for (var i = 0, len = feat.length; i < len; i++) 
			{
				
					tableData.push(
					{
						"OrderNo": resp[i].orderNo,
						"PaymentMethod": resp[i].paymentMethod,
						"Status": resp[i].status,
						"OrderDate": resp[i].orderDate,
						"OrderAmount": resp[i].orderAmount,
						"OrderCurrency": resp[i].orderCurrency,
						"ShipCity": resp[i].shipCity,
						"ShipState": resp[i].shipState,
						"ShipCountry": resp[i].shipCountry,
						"ShipPincode": resp[i].shipPincode,
						"ShippingCharges": resp[i].shippingCharges,
						"StoreCredit": resp[i].storeCredit,
						"Giftvoucher": resp[i].giftvoucher,
						"OtherDiscount": resp[i].otherDiscount,
						"DiscountCode": resp[i].discountCode,
						"PromoCode": resp[i].promoCode,
						"PromoName": resp[i].promoName,
						"DiscountAmount": resp[i].discountAmount,
						"TaxAmount": resp[i].taxAmount,
						"UpdatedDate": resp[i].updatedDate,
						"TotalOrderLine": resp[i].totalOrderLine,
						"OrderSource": resp[i].orderSource,
						"ItemQty": resp[i].items.length
					});
				
				
            }

            table.appendRows(tableData);
            doneCallback();
        });
    };

    tableau.registerConnector(myConnector);

    // Create event listeners for when the user submits the form
    $(document).ready(function() {
        $("#submitButton").click(function() {
            tableau.connectionName = "Venculum Data Feed"; // This will be the data source name in Tableau
            tableau.submit(); // This sends the connector object to Tableau
        });
    });
})();